# Adyen Report Downloader

Downloads scheduled Adyen reports (default: Payment Accounting Report) using Adyen's
predictable report-download URL. No webhook or server needed - just run it whenever
you want to pull the latest files.

It does **not** trigger report generation - the report must already be set to
auto-generate on a schedule in the Adyen Customer Area. This tool only fetches the
files once they exist.

## One-time setup

**In the Adyen Customer Area:**
1. Reports -> \<report type\> (e.g. Payment Accounting) -> Manage report -> set **Automatic generation: On**, pick CSV, daily.
2. Developers -> Users (or API credentials) -> create a **Report** user, assign the Report Download role, and set its password (separate from any normal API key you may already have).
3. Note your **merchant account name** (or company account name) exactly as it appears in the CA.

**On this machine:**

```bash
pip install -r requirements.txt
copy .env.example .env
# edit .env and fill in ADYEN_ACCOUNT_NAME, ADYEN_REPORT_USERNAME, ADYEN_REPORT_PASSWORD,
# and ADYEN_REPORT_TYPE if it's not the accounting report
```

## Usage

Run these from this folder (the one containing `adyen_reports/` and `.env`):

```bash
# Just run it: downloads the current month, 1st through yesterday
python -m adyen_reports

# Missed a month? Backfill it explicitly
python -m adyen_reports --month 2026-07

# Backfill an arbitrary date range, or one specific date
python -m adyen_reports --start 2026-08-01 --end 2026-08-08
python -m adyen_reports --date 2026-08-05
```

Files land in a per-month subfolder: `downloads/2026-07/payments_accounting_report_2026_07_01.csv`, etc. (change `ADYEN_REPORT_DOWNLOAD_DIR` in `.env` to save elsewhere, e.g. a synced SharePoint folder). Re-running the same range skips files that already exist, so running it repeatedly is always safe.

A day with no report (weekend, holiday, no transactions) is reported as "not found" and skipped - that's expected. A real failure (bad credentials, network error) makes the run exit with a non-zero code and print the error.

## Troubleshooting

- **401 Unauthorized**: check `ADYEN_REPORT_USERNAME`/`ADYEN_REPORT_PASSWORD` in `.env`, and that the report user has the Report Download role in the Customer Area.
- **Everything comes back "not found"**: double check `ADYEN_REPORT_TYPE` and `ADYEN_ACCOUNT_NAME` match exactly what's in the report-download URL you can find in the Customer Area's Reports -> Download tab.
- URL pattern used: `https://ca-live.adyen.com/reports/download/MerchantAccount/{ADYEN_ACCOUNT_NAME}/{ADYEN_REPORT_TYPE}_{YYYY_MM_DD}.csv`, authenticated with HTTP Basic Auth using the Report user's credentials.
