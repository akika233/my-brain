﻿Invoice Extractor — portable bundle
===================================

What this does
--------------
1. (Optional) Download invoice PDFs from bosuka DocStore by LREF (Chrome + Selenium)
2. Extract supplier / date / invoice# / PO / HT / TVA into an Excel file

Setup (once)
------------
1. Install Python 3.10+ and Google Chrome
2. Open a terminal (PowerShell or cmd) in THIS folder
3.   python -m pip install -r requirements.txt
4. Copy config.example.env to .env and fill in:
     DOCSTORE_USERNAME=...
     DOCSTORE_PASSWORD=...
     DOCSTORE_COUNTRY=NG
5. VPN / office network required for DocStore downloads

Run — download from DocStore + extract
--------------------------------------
  python -m career.invoice_extractor --from-docstore --country NG --lref 221566 --lref 223663 --download-dir invoice_pdfs --output invoices.xlsx

  PDFs  ->  .\invoice_pdfs\NG_221566.pdf ...
  Excel ->  .\invoices.xlsx

Run — extract PDFs you already have
-----------------------------------
  python -m career.invoice_extractor --input "D:\path\to\pdfs" --output invoices.xlsx

Notes
-----
- Needs Chrome for DocStore (Selenium Manager installs the driver automatically)
- rapidocr-onnxruntime is optional but recommended for logo-only supplier names
- Never commit or share your .env file
- This zip contains only .py / .txt / .env.example style files — no .exe or .bat
