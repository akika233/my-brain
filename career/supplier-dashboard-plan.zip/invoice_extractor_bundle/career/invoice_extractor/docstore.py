"""Download invoice PDFs from bosuka DocStore (Selenium + basic auth).

Working pattern (matches the Aurora/Selenium script):
  1. Open the document page in Chrome with credentials in the URL
  2. Scrape <a href> links that contain both "pdf" and "filename"
  3. Download the PDF bytes with requests + HTTP basic auth

Credentials: DOCSTORE_USERNAME / DOCSTORE_PASSWORD (never hardcode).
"""
from __future__ import annotations

import os
from abc import ABC, abstractmethod
from pathlib import Path
from urllib.parse import quote

import requests


class DocstoreClient(ABC):
    """Fetch invoice PDFs from a document store."""

    @abstractmethod
    def list_pdfs(self) -> list[str]:
        ...

    @abstractmethod
    def download(self, doc_id: str, dest_dir: Path) -> Path:
        ...

    def close(self) -> None:
        return None


class LocalFolderDocstore(DocstoreClient):
    """Read PDFs already on disk (no login)."""

    def __init__(self, folder: Path) -> None:
        self.folder = Path(folder)
        if not self.folder.is_dir():
            raise NotADirectoryError(self.folder)

    def list_pdfs(self) -> list[str]:
        return sorted(p.name for p in self.folder.glob("*.pdf"))

    def download(self, doc_id: str, dest_dir: Path) -> Path:
        src = self.folder / doc_id
        if not src.is_file():
            raise FileNotFoundError(src)
        return src


class BosukaDocstore(DocstoreClient):
    """New Balance DocStore on bosuka1 via Selenium link discovery.

    Document URL shape:
      http://USER:PASS@bosuka1.newbalance.com:6400/docStore/store/NG%20Docstore/document/?L[LREF]=221566
    """

    def __init__(
        self,
        username: str,
        password: str,
        lrefs: list[str] | None = None,
        country: str = "NG",
        base_url: str = "http://bosuka1.newbalance.com:6400",
        headless: bool = True,
    ) -> None:
        if not username or not password:
            raise ValueError(
                "DocStore credentials required. Set DOCSTORE_USERNAME and "
                "DOCSTORE_PASSWORD in career/.env"
            )
        self.username = username
        self.password = password
        self.country = country.strip().upper()
        self.base_url = base_url.rstrip("/")
        # Preserve order, drop blanks / duplicates
        seen: set[str] = set()
        self.lrefs: list[str] = []
        for raw in lrefs or []:
            lref = str(raw).strip()
            if lref and lref not in seen:
                seen.add(lref)
                self.lrefs.append(lref)
        self.headless = headless
        self._driver = None
        self._pdf_urls: dict[str, str] = {}

    @property
    def store_name(self) -> str:
        return f"{self.country} Docstore"

    def document_page_url(self, lref: str, *, with_auth: bool = True) -> str:
        store = quote(self.store_name, safe="")
        path = f"{self.base_url}/docStore/store/{store}/document/?L[LREF]={quote(str(lref), safe='')}"
        if not with_auth:
            return path
        cred = f"{quote(self.username, safe='')}:{quote(self.password, safe='')}"
        # Insert user:pass@ after the scheme, same as the working Selenium script
        return path.replace("://", f"://{cred}@", 1)

    def list_pdfs(self) -> list[str]:
        if not self.lrefs:
            raise ValueError(
                "No LREFs configured. Set DOCSTORE_LREFS=221566,223663 "
                "or pass --lref 221566"
            )
        return list(self.lrefs)

    def download(self, doc_id: str, dest_dir: Path) -> Path:
        dest_dir = Path(dest_dir)
        dest_dir.mkdir(parents=True, exist_ok=True)
        lref = str(doc_id).strip()

        pdf_url = self._pdf_urls.get(lref)
        if pdf_url is None:
            self._discover_pdf_urls([lref])
            pdf_url = self._pdf_urls.get(lref)
        if not pdf_url:
            raise RuntimeError(
                f"No PDF link found for LREF={lref} in {self.store_name}. "
                f"Page: {self.document_page_url(lref, with_auth=False)}"
            )

        resp = requests.get(
            pdf_url,
            auth=(self.username, self.password),
            timeout=120,
        )
        resp.raise_for_status()
        if resp.content[:4] != b"%PDF":
            raise RuntimeError(
                f"Download for LREF={lref} did not return a PDF "
                f"(content-type={resp.headers.get('Content-Type')!r})"
            )

        out = dest_dir / f"{self.country}_{lref}.pdf"
        out.write_bytes(resp.content)
        return out

    def prefetch(self) -> None:
        """Open one Chrome session and resolve PDF links for all LREFs."""
        self._discover_pdf_urls(self.list_pdfs())

    def _ensure_driver(self):
        if self._driver is not None:
            return self._driver
        try:
            from selenium import webdriver
            from selenium.webdriver.chrome.options import Options
        except ImportError as exc:
            raise ImportError(
                "selenium is required for DocStore downloads. "
                "pip install selenium"
            ) from exc

        options = Options()
        if self.headless:
            options.add_argument("--headless=new")
        options.add_argument("--disable-gpu")
        options.add_argument("--no-sandbox")
        self._driver = webdriver.Chrome(options=options)
        return self._driver

    def _discover_pdf_urls(self, lrefs: list[str]) -> None:
        from selenium.webdriver.common.by import By

        driver = self._ensure_driver()
        for lref in lrefs:
            page_url = self.document_page_url(lref, with_auth=True)
            driver.get(page_url)
            pdf_href: str | None = None
            for link in driver.find_elements(By.XPATH, "//a[@href]"):
                href = link.get_attribute("href") or ""
                if "pdf" in href.lower() and "filename" in href.lower():
                    pdf_href = href
            if pdf_href:
                self._pdf_urls[lref] = pdf_href
            else:
                print(f"Warning: no PDF link for LREF={lref} ({self.store_name})")

    def close(self) -> None:
        if self._driver is not None:
            self._driver.quit()
            self._driver = None


def default_invoice_folder() -> Path:
    """Prefer the NB OneDrive Invoice folder when present."""
    configured = os.getenv("INVOICE_DOWNLOAD_DIR") or os.getenv("DOCSTORE_LOCAL_FOLDER")
    if configured:
        return Path(configured)

    candidates = [
        Path(r"C:\Users\shjiang\OneDrive - New Balance Athletics, Inc\Documents\Invoice"),
        Path.home()
        / "OneDrive - New Balance Athletics, Inc"
        / "Documents"
        / "Invoice",
        Path("career/invoice_pdfs"),
    ]
    for path in candidates:
        if path.is_dir():
            return path
    return candidates[0]


def build_docstore_from_env(extra_lrefs: list[str] | None = None) -> DocstoreClient:
    """Build client from environment variables."""
    mode = os.getenv("DOCSTORE_MODE", "local").lower()
    if mode == "local":
        return LocalFolderDocstore(default_invoice_folder())

    if mode in {"nf", "nfdocstore", "bosuka", "docstore"}:
        lrefs_env = os.getenv("DOCSTORE_LREFS", "")
        lrefs = [x.strip() for x in lrefs_env.split(",") if x.strip()]
        if extra_lrefs:
            lrefs.extend(extra_lrefs)
        headless = os.getenv("DOCSTORE_HEADLESS", "1").strip().lower() not in {
            "0",
            "false",
            "no",
        }
        return BosukaDocstore(
            username=os.getenv("DOCSTORE_USERNAME", ""),
            password=os.getenv("DOCSTORE_PASSWORD", ""),
            lrefs=lrefs,
            country=os.getenv("DOCSTORE_COUNTRY", "NG"),
            base_url=os.getenv(
                "DOCSTORE_BASE_URL",
                "http://bosuka1.newbalance.com:6400",
            ),
            headless=headless,
        )

    raise ValueError(
        f"Unknown DOCSTORE_MODE={mode!r} (use local or bosuka/nf)"
    )
